const slider = document.querySelector('.product-grid');

function autoScroll() {
  setInterval(() => {
    slider.scrollBy({
      left: 250, // Adjust this value based on product width
      behavior: 'smooth'
    });
    
    // If reached the end, scroll back to the beginning
    if (slider.scrollLeft >= slider.scrollWidth - slider.clientWidth) {
      slider.scrollTo({ left: 0, behavior: 'smooth' });
    }
  }, 2000); // Adjust the speed as necessary
}

autoScroll();
